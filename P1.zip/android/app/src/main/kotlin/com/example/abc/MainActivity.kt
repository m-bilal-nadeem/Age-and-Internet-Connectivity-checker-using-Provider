package com.example.abc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
